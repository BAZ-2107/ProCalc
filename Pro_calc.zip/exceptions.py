class CheckStringError(Exception):
    pass

class DecodeStringError(Exception):
    pass

class DecodeError(Exception):
    pass

class ConvertError(Exception):
    pass

class CalculateError(Exception):
    pass